const avatar = require('../assets/images/avatar.jpg');
const logo = require('../assets/images/logo.png');

export default {
    avatar,
    logo

}