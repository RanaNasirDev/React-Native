const DATABASE_URL = "Your Realtime Database Url here";
export default DATABASE_URL;
