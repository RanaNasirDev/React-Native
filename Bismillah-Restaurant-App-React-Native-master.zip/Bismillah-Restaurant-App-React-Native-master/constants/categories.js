import { icons } from "."
export const categoryData = [
    {
        id: 1,
        name: "Rolls",
        icon: icons.ch_roll,
    },
    {
        id: 2,
        name: "Burgers",
        icon: icons.burgers,
    },
    {
        id: 3,
        name: "Bar B Q",
        icon: icons.barbq,
    },
    {
        id: 4,
        name: "Handi",
        icon: icons.ch_handi,
    },
    {
        id: 5,
        name: "Karhai",
        icon: icons.ch_karahi,
    },

    {
        id: 6,
        name: "Fish",
        icon: icons.fish,
    },
    {
        id: 7,
        name: "Dal\nSabzi",
        icon: icons.dal,
    },
    {
        id: 8,
        name: "Paratha",
        icon: icons.paratha,
    },
    {
        id: 9,
        name: "Sand\nWiches",
        icon: icons.sandwich,
    },
    {
        id: 10,
        name: "French\nFries",
        icon: icons.french_fries,
    },
    {
        id: 11,
        name: "Drinks",
        icon: icons.cold_drinks,
    },

]